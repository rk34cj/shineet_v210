#ifndef _IPT_HELPER_H
#define _IPT_HELPER_H

#include <linux/netfilter/xt_helper.h>
#define ipt_helper_info xt_helper_info

#endif /* _IPT_HELPER_H */
