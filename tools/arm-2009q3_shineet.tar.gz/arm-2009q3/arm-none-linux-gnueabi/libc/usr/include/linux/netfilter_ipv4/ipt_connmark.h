#ifndef _IPT_CONNMARK_H
#define _IPT_CONNMARK_H

#include <linux/netfilter/xt_connmark.h>
#define ipt_connmark_info xt_connmark_info

#endif /*_IPT_CONNMARK_H*/
