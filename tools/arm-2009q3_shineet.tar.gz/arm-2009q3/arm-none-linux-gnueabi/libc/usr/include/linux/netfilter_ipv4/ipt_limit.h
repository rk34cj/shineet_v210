#ifndef _IPT_RATE_H
#define _IPT_RATE_H

#include <linux/netfilter/xt_limit.h>
#define IPT_LIMIT_SCALE XT_LIMIT_SCALE
#define ipt_rateinfo xt_rateinfo

#endif /*_IPT_RATE_H*/
