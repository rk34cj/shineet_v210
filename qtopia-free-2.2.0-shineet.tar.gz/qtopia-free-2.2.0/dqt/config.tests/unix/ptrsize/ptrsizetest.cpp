/* Sample program for configure to test pointer size on target
platforms.
*/

int main( int, char ** )
{
    return sizeof(void *);
}

