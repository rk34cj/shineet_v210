#!/bin/sh
mknod console c 5 1
mknod null c 1 3
mknod ttySAC0 c 204 64
mknod mtdblock0 b 31 0
mknod mtdblock1 b 31 1
mknod mtdblock2 b 31 2
mknod mtdblock3 b 31 3
mknod mtdblock4 b 31 4
