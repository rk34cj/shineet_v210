#!/bin/sh
export TSLIB_ROOT=/usr/local/tslib
export TSLIB_TSDEVICE=/dev/event1
export TSLIB_CALIBFILE=/etc/pointercal
export TSLIB_CONFFILE=$TSLIB_ROOT/etc/ts.conf
export TSLIB_PLUGINDIR=$TSLIB_ROOT/lib/ts
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_CONSOLEDEVICE=none

export QTDIR=/opt/Qtopia
export QPEDIR=/opt/Qtopia
export QWS_MOUSE_PROTO=TPanel:/dev/event1
export QWS_SIZE=800x480
export QWS_DISPLAY=LinuxFb:/dev/fb0
export QT_PLUGIN_PATH=$QPEDIR/plugins/
export QT_QWS_FONTDIR=$QPEDIR/lib/fonts
export LANG="en_US"
export PATH=$QPEDIR/bin:$TSLIB_ROOT/bin:$PATH
export LD_LIBRARY_PATH=$QPEDIR/lib:/lib:$TSLIB_ROOT/lib:$LD_LIBRARY_PATH
#exec /usr/local/tslib/bin/ts_calibrate
#exec /usr/local/tslib/bin/ts_test
#exec /bin/Writerootfs
exec $QPEDIR/bin/qpe -qws &
